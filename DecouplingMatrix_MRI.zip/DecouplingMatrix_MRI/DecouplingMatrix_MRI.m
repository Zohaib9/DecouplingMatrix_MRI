function DecouplingMatrix_MRI(Touchstonefilename, param)

% This program computes a decoupling matrix to decouple a given coupled 
% multichannel RF array. The decoupling matrix is connected between the 
% RF power amplifiers and the coils. This decoupling matrix minimizes 
% the coupled power lost in circulators and hence improves power efficiency. 
% See references [1,2] for details. NOTE that a single power amplifier
% may drive more than one coils, this has to be accounted for in the
% excitation (pulse sequence) design. 
% 
% 
% COMING SOON - Constraints such as robustness, and predefined upper/lower
% bounds for capacitor and inductor values will be implemented in the 
% second release of this program.
% 
% INPUTs:
%     Touchstonefilename  = Name of the '.SNP' file 
%     LarmorFrequency     = Larmor or operating frequency in Hz
%     NumStartingPts      = The number of starting points used by the 
%                           multistart program to search for a global
%                           optimum. If a satisfactory solution is not 
%                           found at the first attempt, increase this 
%                           number to search a larger space
%     OutputSpicefilename = Name of the output file (if not provided the 
%                           output is saved with the same name as the 
%                           input)
% 
% OUTPUT:
% 
% 1) A plot is created that shows the S-parameters of the original
% coupled coils and the S-parameters of the decoupled coils 
% (using a decoupling matrix) in dBs. (S-parameters of the decoupled
% coils might be of the order of -100dB. This indicates an ideal decoupling
% and matching scenario.)
%
% 2) A spice netlist is generated. The name of this file is specified by 
% OutputSpicefilename. This file is stored in the current working directory.
% The first N-nodes (1 to N) are connected to the power amplifiers while
% the second N-nodes (N+1 to 2N) are connected to the coils.
%
% - A reactive element Xi_j in the spice netlist indicates that X is 
% connected between the nodes 'i' and 'j'.
% - A reactive element Xi_i in the spice netlist indicates that X is
% connected between the node 'i' and GND
% L is used for a inductor (spice convention)
% C is used for a capacitor (spice convention)
% For example:
% L4_8 is an inductor connected between nodes N3 and N4 
% C2_6 is a capacitor connected between nodes N2 and N6
% C1_1 is a capacitor connected between node N1 and GND
%
% Feel free to send me an email at zohaib@mit.edu if you have any
% questions, or if you would like to define additional constraints.
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%
% References: Following papers must be cited if the code is used in a 
% scientific work

% 1) Z. Mahmood, B. Gu�rin, E. Adalsteinsson, L. Wald, and L. Daniel, 
% ?An Automated Framework to Decouple pTx Arrays with Many Channels,? 
% in Proc. of 21st Annual Meeting & Exhibition of International Society 
% for Magnetic Resonance in Medicine (ISMRM), Apr. 2013.
% 
% 2) Z. Mahmood, B. Gu�rin, B. Keil, E. Adalsteinsson, L. L. Wald and 
% L. Daniel. ?Design of a Robust Decoupling Matrix for High Field Parallel 
% Transmit Arrays? in Proc. of 22nd Annual Meeting & Exhibition of 
% International Society for Magnetic Resonance in Medicine (ISMRM), 
% May. 2014.
% 
% 
% This is v1.0 of the function DecouplingMatrix_MRI
% Feedback/Questions - zohaib@alum.mit.edu
%
% Copyright (C) 2014, Zohaib Mahmood (zohaib@alum.mit.edu)
% Massachusetts Institute of Technology
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargin < 1
    % Run the Sample program
    display('No input provided, running the demo')
    Touchstonefilename  = 'SampleTouchstone.S4P';
    LarmorFrequency     = 297.2e6;       % Larmor frequency in Hz
    displayData         = 1;             % 0 to supress all plots
    NumStartingPts      = 50;            
    OutputSpicefilename = 'SampleOutput';
elseif nargin <2
    error('Please provide input parameters')
else
    LarmorFrequency     = param.LarmorFrequency;
    if isfield(param,'NumStartingPts')
        NumStartingPts      = param.NumStartingPts;
    else NumStartingPts = 10; 
    end
    if isfield(param,'OutputSpicefilename')
        OutputSpicefilename = param.OutputSpicefilename;
    else OutputSpicefilename = Touchstonefilename(1:end-4); 
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Importing Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
data1 = read(rfdata.data, Touchstonefilename);
freq = data1.Freq;
S = extract(data1,'S_PARAMETERS');
for k=1:length(freq)
    S(:,:,k) = 0.5*(S(:,:,k)+S(:,:,k).');
end

Ym=s2y(S);
global N Y Yu YLAR YLARp YLARm wLAR wLARp wLARm;

[temp1 iLAR] = min(abs(freq-LarmorFrequency ));
fLAR = freq(iLAR);



SLAR = S(:,:,iLAR);
YLAR = Ym(:,:,iLAR);
wLAR = 2*pi*fLAR;


N=size(S,1);

Zc = 50;
Zu = Zc*eye(N);
Yu = z2y(Zu);
Y  = YLAR;

numCaps = N*(2*N+1); % number of capacitors and inductors
numVars = numCaps;

thisY = rand(1,numVars);
StartingPoints = logspace(1,-5,NumStartingPts)'*rand(1,numVars);

startpts = CustomStartPointSet(StartingPoints);

opts = optimoptions(@lsqnonlin,'MaxFunEvals',1000000*numVars,...
    'MaxIter',100000,'Algorithm','levenberg-marquardt');

problem = createOptimProblem('lsqnonlin','objective',...
    @myfun,'x0',thisY,'options',opts);

ms = MultiStart('Display','iter');
[tY,f] = run(ms,problem,startpts);

bigY=1i*mss_v2s(tY); % currently real

Y11 = bigY(1:N,1:N);
Y12 = bigY(1:N,N+1:2*N);
Y21 = bigY(1+N:2*N,1:N);
Y22 = bigY(1+N:2*N,1+N:2*N);

Yout = Y11 - Y12*inv(Y22 + Y)*Y21;
Sout = y2s(Yout);
Y_DM = [Y11 Y12 ; Y21 Y22];
Y2Hspice_DM(Y_DM,wLAR,OutputSpicefilename)

min_Sout = min([(min(min(mag2db(abs(SLAR))))) ; (min(min(mag2db(abs(Sout)))))])
figure, 
subplot(1,2,1); imagesc(mag2db(abs(SLAR)),[min_Sout 0]), 
title('Original S-parameters (dB)')
subplot(1,2,2); imagesc(mag2db(abs(Sout)),[min_Sout 0]), 
colorbar; 
title('S-parameters WITH a decoupling matrix (dB)')

keyboard


function F=myfun(tY)

global Y Yu N;
bigY=1i*mss_v2s(tY); 

Y11 = bigY(1:N,1:N);
Y12 = bigY(1:N,N+1:2*N);
Y21 = bigY(1+N:2*N,1:N);
Y22 = bigY(1+N:2*N,1+N:2*N);

F1 = Y11 - Y12*inv(Y22 + Y)*Y21 - Yu;

F = [F1(:)];
F = [abs(real(F)) ; abs(imag(F))];

function y=mss_v2s(x,z)
% function y=mss_v2s(x,z)
%
% with nargin==1, re-arrange the rows of x into block symmetric matrix
%     [ x(1) x(2) x(4)    ]
%     [ x(2) x(3) x(5)    ]
% y = [ x(4) x(5) x(6)    ]
%     [               ... ]
% with nargin>1, use the scheme
%                                 [  4  5  6  7  ]
%          [ 2 3 4 ]              [  5  1  2  8  ]
% (1:6) -> [ 3 1 5 ],   (1:10) -> [  6  2  3  9  ],   etc.
%          [ 4 5 6 ]              [  7  8  9  10 ]
%

% AM 10.01.09
% This function is written by Prof. Alex Megretski at MIT

x=x(:);
n=size(x,1);
m=round((sqrt(1+8*n)-1)/2);
if m*(m+1)~=2*n, error('unable to convert: wrong dimension'); end

ii=repmat(1:m,m,1);         % column number in an m-by-m matrix
jj=repmat((1:m)',1,m);      % row number
a=min(ii,jj);
b=max(ii,jj);
if nargin<2,
    h=a+round(b.*(b-1)/2);
else
    e=2*min(a,m-b+1)-1;
    c=m-e;
    d=b+a-e;
    h=d+round(c.*(c-1)/2);
end

y=x(h);


function Y2Hspice_DM(Ycmplx,w,filename)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           Y2Hspice
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function converts a Y matrix describing a
% decoupling matrix into an equivalent Hspice netlist.

if (sum(sum(real(Ycmplx)))~=0)
    error('Real part of Y is non zero')
end
Yi = imag(Ycmplx);
fname=[filename '.sp'];
fid=fopen(fname,'w');
nodes= size(Ycmplx,1);

header=['.SUBCKT ' filename ' '];
for i=1:nodes
    header=[header 'N' num2str(i) ' '];
end
header=[header '\n'];
fprintf(fid,header);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Writing Model Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Writing OFF-Diagonal Y elements
for i=1:size(Ycmplx,1)-1
    for j=i+1:size(Ycmplx,2)
        thisY = -1*Yi(i,j);
        if (thisY>0) % a capacitor
            thisC = thisY./w;
            fprintf(fid,['C' int2str(i) '_' int2str(j) ' N' int2str(i) ' N' int2str(j) sprintf('  %1.16e',thisC) ' \n']);
        elseif(thisY<0) % an inductor
            thisL = -1/(thisY*w);
            fprintf(fid,['L' int2str(i) '_' int2str(j) ' N' int2str(i) ' N' int2str(j) sprintf('  %1.16e',thisL) ' \n']);
        end % Yi == 0 => an open circuit, do nothing
    end
end

% Writing Diagonal elements
for i=1:size(Ycmplx,1)
    thisY= sum(Yi(i,:));
    if (thisY>0) % a capacitor
        thisC = thisY./w;
        fprintf(fid,['C' int2str(i) '_' int2str(i) ' N' int2str(i) ' 0'  sprintf('  %1.16e',thisC) ' \n']);
    elseif(thisY<0) % an inductor
        thisL = -1/(thisY*w);
        fprintf(fid,['L' int2str(i) '_' int2str(i) ' N' int2str(i) ' 0'  sprintf('  %1.16e',thisL) ' \n']);
    end % Yi == 0 => an open circuit, do nothing
end

fprintf(fid,['\n']);

fprintf(fid,'.ENDS \n');
fclose(fid);