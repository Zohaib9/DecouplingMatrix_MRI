% See 'DecouplingMatrix_MRI.m' for details 

% Feel free to send me your touchstone file (.SNP) if the program does not
% generate desired results or you'd like to include additional constraints
% email: zohaib@alum.mit.edu



Touchstonefilename        = 'SampleTouchstone.S4P';
param.LarmorFrequency     = 297.2e6;       % Larmor frequency in Hz
param.NumStartingPts      = 50;            % Increase this number to search a 
                                     % larger space
param.OutputSpicefilename = 'SampleOutput';


DecouplingMatrix_MRI(Touchstonefilename, param)